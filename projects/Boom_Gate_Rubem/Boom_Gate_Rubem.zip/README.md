
## Para conectar no TXT 4.0 via USB no FileZilla

Servidor: ssh://192.168.7.2
Port: 22
Username: ft
Password: fischertechnik

## TODOs

- Usar algum plug-in que sincronize os arquivos automaticamente via SSH; aí não precisa usar o FileZilla. Ver `Remote - SSH`
- Será que existe um meio de transpilar automaticamente do JS para o Python?
