import time
from fischertechnik.controller.Motor import Motor
from lib.controller import *
from lib.display import *

speed = None
Counter = None


speed = 200
Counter = 0
while True:
    TXT_M_M1_encodermotor.set_speed(int(speed), Motor.CW)
    TXT_M_M1_encodermotor.start_sync()
    while True:
        if (TXT_M_I1_mini_switch.is_closed()):
            break
        time.sleep(0.010)
    TXT_M_M1_encodermotor.stop_sync()
    while True:
        if (TXT_M_I2_mini_switch.is_closed()):
            break
        time.sleep(0.010)
    time.sleep(3)
    TXT_M_M1_encodermotor.set_speed(int(speed), Motor.CCW)
    TXT_M_M1_encodermotor.set_distance(int(64))
    while True:
        if (not TXT_M_M1_encodermotor.is_running()):
            break
        time.sleep(0.010)
    while True:
        if (TXT_M_I3_photo_transistor.is_dark()):
            break
        time.sleep(0.010)
    while True:
        if (TXT_M_I3_photo_transistor.is_bright()):
            break
        time.sleep(0.010)
    Counter = (Counter if isinstance(Counter, (int, float)) else 0) + 1
    time.sleep(1)
    display.set_attr("passages.text", str('Passages: ' + str(Counter)))
